export interface Favorite {
  movieId: number;
  userId: number;
  id: number;
}
